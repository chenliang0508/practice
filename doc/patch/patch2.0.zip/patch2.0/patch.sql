-- Create table
create table TP_CUL_PACKAGE
(
  project_name  VARCHAR2(20) not null,
  web_content   VARCHAR2(30) not null,
  java_content  VARCHAR2(30) not null,
  java_parent   VARCHAR2(20) not null,
  class_path    VARCHAR2(30) not null,
  svn           VARCHAR2(150) not null,
  branch_url    VARCHAR2(100) not null,
  is_maven      VARCHAR2(1) not null,
  target_ver    VARCHAR2(5) not null,
  source_ver    VARCHAR2(5) not null,
  project_order VARCHAR2(1) not null
);
-- Add comments to the table 
comment on table TP_CUL_PACKAGE
  is '��Ŀ������ñ�';
-- Create/Recreate primary, unique and foreign key constraints 
alter table TP_CUL_PACKAGE
  add constraint PK_PRI_PACKAGE primary key (PROJECT_NAME);

-- Data 
insert into TP_CUL_PACKAGE (PROJECT_NAME, WEB_CONTENT, JAVA_CONTENT, JAVA_PARENT, CLASS_PATH, SVN, BRANCH_URL, IS_MAVEN, TARGET_VER, SOURCE_VER, PROJECT_ORDER)
values ('mpayms', 'src/main/webapp', 'src/main/java', 'com', 'WEB-INF/classes', 'http://192.168.2.240:8080/svn/mpayms', '/trunk/mpayms', 'Y', '1.7', '1.7', '1');

insert into TP_CUL_PACKAGE (PROJECT_NAME, WEB_CONTENT, JAVA_CONTENT, JAVA_PARENT, CLASS_PATH, SVN, BRANCH_URL, IS_MAVEN, TARGET_VER, SOURCE_VER, PROJECT_ORDER)
values ('culsite', 'WebRoot', 'src', 'cn|com', 'WEB-INF/classes', 'http://192.168.2.240:8080/svn/culsite', '/trunk/culsite', 'N', '1.6', '1.6', '3');

insert into TP_CUL_PACKAGE (PROJECT_NAME, WEB_CONTENT, JAVA_CONTENT, JAVA_PARENT, CLASS_PATH, SVN, BRANCH_URL, IS_MAVEN, TARGET_VER, SOURCE_VER, PROJECT_ORDER)
values ('vcweixin', 'WebRoot', 'src', 'cn', 'WEB-INF/classes', 'http://192.168.2.240:8080/svn/weixin', '/branches/vcweixin', 'N', '1.7', '1.7', '2');
 